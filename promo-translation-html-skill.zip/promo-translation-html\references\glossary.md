# iGaming Terminology Glossary — Promo Translation HTML Skill

Approved translations for iGaming / online casino promotional terms. The skill consults this list whenever translating, uses approved terms verbatim, and auto-appends new KM/ID entries as they are discovered.

## How to Use

- Always consult this list first. If an approved entry exists for the target language, USE IT verbatim.
- If an EN term has no row → translate naturally, then append a new row with the translation and `[auto-added YYYY-MM-DD]`. Mark all unfilled cells `[TBD]`.
- If a row exists but the target-language cell is empty → fill it with `<translation> [auto-added YYYY-MM-DD]`.
- **Never overwrite curated cells** (ZH-Simp, ZH-Trad, TH, BM). If you spot a mistake, flag it in the report; don't edit.
- Every auto-add must appear in the final translation report so the user can confirm/correct.

## Approved Terms

| EN Term | CN (Simplified) | CN (Traditional) | TH | KM | ID | BM | Notes |
|---------|-----------------|-------------------|----|----|----|----|----|
| Turnover (TO) | 流水 | 流水 | ยอดเทิร์นโอเวอร์ | Turnover [auto-added 2026-05-14] | Turnover [auto-added 2026-05-14] | Turnover | KM/ID: kept in English; iGaming convention |
| Wagering Requirement | 流水要求 | 流水要求 | ข้อกำหนดการเดิมพัน | [TBD] | Persyaratan Wagering [auto-added 2026-05-14] | Keperluan Pertaruhan | |
| Free Credit | 免费彩金 | 免費彩金 | เครดิตฟรี | ឥណទានឥតគិតថ្លៃ [auto-added 2026-05-14] | Kredit Gratis [auto-added 2026-05-14] | Kredit Percuma | ZH "彩金" rather than "信用额" |
| Free Spin | 免费旋转 | 免費旋轉 | ฟรีสปิน | [TBD] | Free Spin [auto-added 2026-05-14] | Pusingan Percuma | ID: kept in English in iGaming context |
| Deposit Bonus | 存款红利 | 存款紅利 | โบนัสเงินฝาก | [TBD] | Bonus Deposit [auto-added 2026-05-14] | Bonus Deposit | |
| Minimum Deposit | 最低存款 | 最低存款 | ฝากขั้นต่ำ | [TBD] | Deposit Minimum [auto-added 2026-05-14] | Deposit Minimum | |
| Maximum Withdrawal | 最高提款 | 最高提款 | ถอนสูงสุด | [TBD] | Penarikan Maksimum [auto-added 2026-05-14] | Pengeluaran Maksimum | |
| Terms & Conditions | 条款与条件 | 條款與條件 | ข้อกำหนดและเงื่อนไข | លក្ខខណ្ឌនិងលក្ខន្តិកៈ [auto-added 2026-05-14] | Syarat dan Ketentuan [auto-added 2026-05-14] | Terma & Syarat | |
| Eligible Games | 合格游戏 | 合格遊戲 | เกมที่ร่วมรายการ | ហ្គេមដែលចូលរួម [auto-added 2026-05-14] | Permainan yang Berpartisipasi [auto-added 2026-05-14] | Permainan Layak | |
| Promo Period | 活动期间 | 活動期間 | ระยะเวลาโปรโมชั่น | រយៈពេលនៃកម្មវិធី [auto-added 2026-05-14] | Periode Promo [auto-added 2026-05-14] | Tempoh Promosi | |
| Multiplier | 倍数 [auto-added 2026-05-14] | 倍數 [auto-added 2026-05-14] | ตัวคูณ [auto-added 2026-05-14] | តួគុណ [auto-added 2026-05-14] | Multiplier [auto-added 2026-05-14] | Multiplier [auto-added 2026-05-14] | All: ID/BM keep in EN, ZH/TH/KM translate. Used in tournament/slot contexts. |
| Leaderboard | 排行榜 [auto-added 2026-05-14] | 排行榜 [auto-added 2026-05-14] | กระดานผู้นำ [auto-added 2026-05-14] | តារាងលំដាប់ [auto-added 2026-05-14] | Papan Peringkat [auto-added 2026-05-14] | Papan Peringkat [auto-added 2026-05-14] | |
| Tournament | 锦标赛 [auto-added 2026-05-14] | 錦標賽 [auto-added 2026-05-14] | ทัวร์นาเมนต์ [auto-added 2026-05-14] | ការប្រកួត [auto-added 2026-05-14] | Turnamen [auto-added 2026-05-14] | Kejohanan [auto-added 2026-05-14] | |
| Daily Tournament | 每日锦标赛 [auto-added 2026-05-14] | 每日錦標賽 [auto-added 2026-05-14] | ทัวร์นาเมนต์รายวัน [auto-added 2026-05-14] | ការប្រកួតប្រចាំថ្ងៃ [auto-added 2026-05-14] | Turnamen Harian [auto-added 2026-05-14] | Kejohanan Harian [auto-added 2026-05-14] | |
| Grand Tournament | 总锦标赛 [auto-added 2026-05-14] | 總錦標賽 [auto-added 2026-05-14] | ทัวร์นาเมนต์ใหญ่ [auto-added 2026-05-14] | ការប្រកួតប្រជែងធំ [auto-added 2026-05-14] | Turnamen Akbar [auto-added 2026-05-14] | Kejohanan Agung [auto-added 2026-05-14] | |
| Lucky Draw | 幸运抽奖 [auto-added 2026-05-14] | 幸運抽獎 [auto-added 2026-05-14] | จับรางวัล [auto-added 2026-05-14] | ការចាប់ឆ្នោត [auto-added 2026-05-14] | Undian [auto-added 2026-05-14] | Cabutan Bertuah [auto-added 2026-05-14] | |
| Grand Prize | 特等奖 [auto-added 2026-05-14] | 特等獎 [auto-added 2026-05-14] | รางวัลใหญ่ [auto-added 2026-05-14] | រង្វាន់ធំ [auto-added 2026-05-14] | Hadiah Utama [auto-added 2026-05-14] | Hadiah Utama [auto-added 2026-05-14] | |
| Player Inbox | 站内信 [auto-added 2026-05-14] | 站內信 [auto-added 2026-05-14] | กล่องข้อความผู้เล่น [auto-added 2026-05-14] | ប្រអប់សារអ្នកលេង [auto-added 2026-05-14] | Inbox Pemain [auto-added 2026-05-14] | Peti Masuk Pemain [auto-added 2026-05-14] | |
| Single Receipt | 单笔单据 [auto-added 2026-05-14] | 單筆單據 [auto-added 2026-05-14] | ใบเสร็จเดียว [auto-added 2026-05-14] | វិក្កយបត្រតែមួយ [auto-added 2026-05-14] | Satu Kuitansi [auto-added 2026-05-14] | Satu Resit [auto-added 2026-05-14] | |
| Ticket (lucky draw) | 抽奖券 [auto-added 2026-05-14] | 抽獎券 [auto-added 2026-05-14] | ตั๋วจับรางวัล [auto-added 2026-05-14] | សំបុត្រចាប់ឆ្នោត [auto-added 2026-05-14] | Tiket Undian [auto-added 2026-05-14] | Tiket Cabutan [auto-added 2026-05-14] | |
| Promotion Details | 活动详情 [auto-added 2026-05-14] | 活動詳情 [auto-added 2026-05-14] | รายละเอียดโปรโมชั่น [auto-added 2026-05-14] | ព័ត៌មានលម្អិតនៃកម្មវិធី [auto-added 2026-05-14] | Detail Promosi [auto-added 2026-05-14] | Butiran Promosi [auto-added 2026-05-14] | |
| Rewards | 奖品 [auto-added 2026-05-14] | 獎品 [auto-added 2026-05-14] | รางวัล [auto-added 2026-05-14] | រង្វាន់ [auto-added 2026-05-14] | Hadiah [auto-added 2026-05-14] | Ganjaran [auto-added 2026-05-14] | "Rewards" as table header in promo docs |
| Quantity | 数量 [auto-added 2026-05-14] | 數量 [auto-added 2026-05-14] | จำนวน [auto-added 2026-05-14] | ចំនួន [auto-added 2026-05-14] | Jumlah [auto-added 2026-05-14] | Kuantiti [auto-added 2026-05-14] | |
| Rank | 排名 [auto-added 2026-05-14] | 排名 [auto-added 2026-05-14] | อันดับ [auto-added 2026-05-14] | លំដាប់ [auto-added 2026-05-14] | Peringkat [auto-added 2026-05-14] | Kedudukan [auto-added 2026-05-14] | |
| Pro Account | Pro 账户 [auto-added 2026-05-14] | Pro 賬戶 [auto-added 2026-05-14] | บัญชี Pro [auto-added 2026-05-14] | គណនី Pro [auto-added 2026-05-14] | Akun Pro [auto-added 2026-05-14] | Akaun Pro [auto-added 2026-05-14] | "Pro" stays in English; surrounding word translates |

## Do Not Translate List

The following must ALWAYS remain in English / as-is in all translations:

- **Brand names** — every wallet-family brand: MB8, RWS77, BP9, QPRO1–QPRO19, QP2A/B/C/D (IBC22, KING333, ACE66, SPADE66), MEI707, etc.
- **Game provider names** — MICROGAMING, Pragmatic Play, Habanero, Spadegaming, JILI, PG Soft, etc.
- **Individual game titles** — every slot/casino game name, regardless of language (e.g. `123 Soccer Link & Merge`, `Lucky Twins Wilds`, `Bountiful Birds`)
- **Currency codes** — `MYR`, `SGD`, `USD`, `THB`, `Rp` only. NEVER `RM`, `IDR`, `$`, `฿`, `S$`, `US$`, `¥`
- **Currency formatting** — `[CURRENCY] [amount]` with single space (`MYR 200`, `Rp 100,000`)
- **Currency amounts** — NEVER convert. If EN says `MYR 200`, every translation says `MYR 200`.
- **Dates** — mirror source format exactly (`01/06/2026 00:01`, `07 June 2026 00:00 (GMT+8)`)
- **Product/luxury item names** — Samsung Galaxy Z TriFold, Rolex Oyster Perpetual 41, Daniel Roth Extra Plat, Bang & Olufsen Beoplay H100, iPhone 17 Pro Max, Bose Lifestyle Ultra Soundbar, Asus Zenbook Duo Laptop, Nintendo Switch 2, etc.
- **App names** — WhatsApp, Telegram, Live Chat, SMS
- **Template placeholders** — `:brandname`, `[BRAND]`, `{merchant}`, `<<token>>` — preserve literally and flag in report
- **In-game identifiers** — `"Alias"` in quotes, similar UI labels
- **Promo codes**, **URLs**, **email addresses**

## Adding New Terms (auto-append)

When the skill encounters a new iGaming term not in this glossary OR an existing term without a translation for the target language:

1. Translate naturally, considering existing convention for that language
2. Append a new row or fill the empty cell with `<translation> [auto-added YYYY-MM-DD]`
3. Mark all language cells you didn't fill this run as `[TBD]`
4. List every auto-add in the final translation report for user review

**Never auto-modify** ZH-Simp, ZH-Trad, TH, or BM cells. Those are human-curated. Flag any concerns but do not overwrite.
